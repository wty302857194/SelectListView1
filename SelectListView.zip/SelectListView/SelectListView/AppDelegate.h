//
//  AppDelegate.h
//  SelectListView
//
//  Created by wbb on 16/11/9.
//  Copyright © 2016年 wbb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

