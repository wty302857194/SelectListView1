//
//  ViewController.m
//  SelectListView
//
//  Created by wbb on 16/11/9.
//  Copyright © 2016年 wbb. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)firstBtnClick:(UIButton *)sender {
    ListSelectView *select_view = [[ListSelectView alloc] initWithFrame:self.view.bounds];
    
    select_view.choose_type = MORECHOOSETITLETYPE;
    select_view.isShowCancelBtn = YES;
    select_view.isShowSureBtn = YES;
    select_view.isShowTitle = YES;
    NSArray *arr= @[@"one",@"two",@"three",@"four",@"five",@"six"];
    [select_view addTitleArray:arr andTitleString:@"标题" animated:YES completionHandler:^(NSString * _Nullable string, NSInteger index) {
        
        NSLog(@"%@------%ld",string,(long)index);
    } withSureButtonBlock:^{
        NSLog(@"sure btn");
    }];
    [self.view addSubview:select_view];
}

- (IBAction)secondBtnClick:(UIButton *)sender {
    ListSelectView *select_view = [[ListSelectView alloc] initWithFrame:self.view.bounds];
    
    select_view.choose_type = ONLYTEXTTYPE;
//    select_view.isShowCancelBtn = YES;
    select_view.isShowSureBtn = YES;
//    select_view.isShowTitle = YES;
    select_view.content_text = @"这是一个自定义的弹出框 实现了弹框所需的基本要求分为：1、提示弹框 2、选择弹框 感兴趣的同学可以下载看一下相信不会让大家失望。";

    [select_view addTitleArray:nil andTitleString:@"标题" animated:YES completionHandler:^(NSString * _Nullable string, NSInteger index) {
        NSLog(@"%@------%ld",string,(long)index);
    } withSureButtonBlock:^{
        NSLog(@"sure btn");
    }];
    [self.view addSubview:select_view];
}
@end
