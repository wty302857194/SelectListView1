//
//  ViewController.h
//  SelectListView
//
//  Created by wbb on 16/11/9.
//  Copyright © 2016年 wbb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)firstBtnClick:(UIButton *)sender;
- (IBAction)secondBtnClick:(UIButton *)sender;


@end

